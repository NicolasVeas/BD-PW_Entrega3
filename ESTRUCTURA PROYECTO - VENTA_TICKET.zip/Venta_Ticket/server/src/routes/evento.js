const express = require('express');
const router = express.Router();

const conn = require('../database');

// router.get('/correcto', (req,res,next)=>{
//     if(req.isAuthenticated()) return next();
        
//         res.redirect('/login');
// },(req,res) =>{
//         res.render('evento.ejs');
// });
    
//evento vista de usuario
router.get('/usuario/evento', (req,res,next) => {
       
    if(req.isAuthenticated()){ 
        //console.log(req.user)
        return next();
    }
        res.redirect('/login');
},(req,res) =>{
    conn.query('Select * FROM evento', (err,resp,campos) => {
        //console.log(req.user)
        res.render('home.ejs',{
            datos: resp
        });
    });
});

router.get('/administrador/tickets/all', (req,res,next) => {
    if(req.isAuthenticated()){
        if(req.user.tipo == 'comprador' ){
            res.redirect('/usuario/evento');
        }
        return next();
    
    }
        res.redirect('/login');
},(req,res) =>{
    conn.query('Select * FROM ticket', (err,resp,campos) => {
        res.render('tickets_evento.ejs',{
            datos: resp
        });
    });
});


// mostrar todos los eventos
router.get('/evento', (req,res,next) => {
    if(req.isAuthenticated()){
        if(req.user.tipo == 'comprador' ){
            res.redirect('/usuario/evento');
        }
        return next();
    
    }
        res.redirect('/login');
},(req,res) =>{
    conn.query('Select * FROM evento', (err,resp,campos) => {
        res.render('evento.ejs',{
            datos: resp
        });
    });
});



//actualizar 1 evento
router.post('/actualizar/:id', (req, res) => {
    const { id } = req.params;
    const newCus = req.body;
    //console.log(req.body);
    conn.query('UPDATE evento SET ? where id_evento = ?', [newCus, id], (err, result) => {
        if(!err) {
            res.redirect('/evento');
        } else {
            console.log(err);
        }
    });
});

//ingresar un evento
router.post('/ingresar',(req, res) => {
    //console.log(req.body);
    const {nombre, fecha, hora, lugar, descripcion, categoria, capacidad, imagen} = req.body;
    conn.query('INSERT into evento SET? ',{
        nombre: nombre,
        fecha: fecha,
        hora: hora,
        lugar: lugar,
        descripcion: descripcion,
        categoria: categoria,
        capacidad: capacidad,
        imagen: imagen
    }, (err, result) => {
        if(!err) {
            res.redirect('/evento');
        } else {
            console.log(err);
        }
    });
});

//eliminar un evento
router.get('/eliminar/:id', (req,res) =>{
    const { id } = req.params;
    conn.query('DELETE from evento WHERE id_evento = ?', [id], (err, resp, campos) => {
        if(!err){ 
            res.redirect('/evento')
        }else{
            console.log(err);
        }
    });
});

//seleccionar 1 evento
router.get('/actualizar/:id', (req,res) =>{
    const { id } = req.params;
    conn.query('SELECT * FROM evento WHERE id_evento = ?', [id], (err, resp, campos) => {
        if(!err){ 
            //console.log(resp[0]);
            res.render('evento_edit.ejs',{
                datos: resp[0]
                
            });
        }else{
            console.log(err);
        }
    });
});

// CATEGORIAS

router.get('/usuario/categoria/conciertos', (req,res,next) => {    
    if(req.isAuthenticated()){ 
        //console.log(req.user)
        return next();
    }
        res.redirect('/login');
},(req,res) =>{
    conn.query("Select * FROM evento where categoria = 'conciertos'", (err,resp,campos) => {
        //console.log(req.user)
        res.render('categorias.ejs',{
            datos: resp
        });
    });
});

router.get('/usuario/categoria/culturales', (req,res,next) => {    
    if(req.isAuthenticated()){ 
        //console.log(req.user)
        return next();
    }
        res.redirect('/login');
},(req,res) =>{
    conn.query("Select * FROM evento where categoria = 'culturales'", (err,resp,campos) => {
        //console.log(req.user)
        res.render('categorias.ejs',{
            datos: resp
        });
    });
});

router.get('/usuario/categoria/especiales', (req,res,next) => {    
    if(req.isAuthenticated()){ 
        //console.log(req.user)
        return next();
    }
        res.redirect('/login');
},(req,res) =>{
    conn.query("Select * FROM evento where categoria = 'especiales'", (err,resp,campos) => {
        //console.log(req.user)
        res.render('categorias.ejs',{
            datos: resp
        });
    });
});

router.get('/usuario/categoria/familiares', (req,res,next) => {    
    if(req.isAuthenticated()){ 
        //console.log(req.user)
        return next();
    }
        res.redirect('/login');
},(req,res) =>{
    conn.query("Select * FROM evento where categoria = 'familiares'", (err,resp,campos) => {
        //console.log(req.user)
        res.render('categorias.ejs',{
            datos: resp
        });
    });
});

router.get('/usuario/categoria/deportes', (req,res,next) => {    
    if(req.isAuthenticated()){ 
        //console.log(req.user)
        return next();
    }
        res.redirect('/login');
},(req,res) =>{
    conn.query("Select * FROM evento where categoria = 'deportes'", (err,resp,campos) => {
        //console.log(req.user)
        res.render('categorias.ejs',{
            datos: resp
        });
    });
});


// EVENTO -> PRODUCTO

router.get('/usuario/evento/:id', (req,res,next) => {    
    
    if(req.isAuthenticated()){ 
        //console.log(req.user)
        return next();
    }
        res.redirect('/login');
},(req,res) =>{
    const { id } = req.params;
    conn.query('SELECT * FROM evento WHERE id_evento = ?', [id] , (err,resp,campos) => {
        //console.log(req.user)
        if(!err){ 
            //console.log(resp[0]);
            res.render('home_producto.ejs',{
                
                datos: resp[0]
                
            });
        }else{
            console.log(err);
        }
        
    });

});

// obtener tickets sin dueño
router.get('/usuario/evento/comprar/:id', (req,res) =>{
    const { id } = req.params;
    conn.query("SELECT * FROM `ticket` WHERE id_evento = '" + [id] + "' and id_usuario is null and disponible = 1", [id], (err, resp, campos) => {
        if(!err){ 
            res.render('comprar_1.ejs',{
                
            datos: resp
                
            });
        }else{
            console.log(err);
        }
    });
});

//insertar compra
router.post('/compra/finalizar/:id',(req, res) => {
   // console.log(req.body);
    const { id } = req.params;
    var fecha = new Date();
    let date = JSON.stringify(fecha);
    date = date.slice(1,11);
    //console.log(date);
    var hora = fecha.getHours() + ":" + fecha.getMinutes() + ":" + fecha.getSeconds();
    // console.log(hora);  
    //console.log(id);
    conn.query('INSERT into venta SET? ',{
        monto_total: req.body.monto_total,
        direccion: req.body.direccion,
        hora: hora,
        fecha: date
    }, (err, result) => {
        if(!err) {
            res.redirect('/usuario/evento');
        } else {
            console.log(err);
        }
    });

   // console.log(req.user);
    conn.query("UPDATE ticket SET id_usuario = '"+ req.user.id_usuario + "', disponible = 0 where id_ticket = '" + id + "'",  (err, result) => {
        if(!err) {
            console.log("COMPRA FINALIZADA");
        } else {
            console.log(err);
        }
    });

    // conn.query("Select * from venta order by id_venta desc limit 1",  (err, result) => {
    //     if(!err) {
    //         console.log(result[0].id_venta);
            
    //     } else {
    //         console.log(err);
    //     }
    // });

    var someVar = [];

    conn.query("Select * from venta order by id_venta desc limit 1", function(err, rows){
        if(err) {
        throw err;
        } else {
        setValue(rows);
        }
    });

    function setValue(value) {
        someVar = value;
        console.log(someVar[0].id_venta);
        console.log(id);

        conn.query('INSERT into ticket_venta SET? ',{
            id_ticket: id,
            id_venta: someVar[0].id_venta
        }, (err, result) => {
            if(!err) {
                console.log("hola");
            } else {
                console.log(err);
            }
        });
        
        
   }

   
});

/*
router.get('/evento/:id', (req,res) =>{
    const { id } = req.params;
    conn.query('Select * from evento WHERE id_evento = ?', [id], (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});

router.delete('/evento/:id',(req, res) => {
    const { id } = req.params;
    conn.query('DELETE FROM evento WHERE id_evento = ?', [id],(err,resp,campos) =>{
        if(!err) {            
            res.json({status: 'Evento borrado sin problemas...'});
        } else {
            console.log(err);
        }
    });
}); 

router.put('/evento/:id',(req, res) => {
    const { id } = req.params;
    conn.query('UPDATE evento SET fecha="2020-10-18", hora="19:00:00", lugar="Plaza Vergara", nombre="Mega Ultra Ramada 18chera", categoria="especiales", imagen=null, capacidad=100 WHERE id_evento = ?', [id],(err,resp,campos) =>{
        if(!err) {            
            res.json({status: 'Evento modificado sin problemas...'});
        } else {
            console.log(err);
        }
    });
});*/
module.exports = router;