const express = require('express');
const router = express.Router();

const conn = require('../database');

// router.put('/usuario/edit/table', (req,res) => {
//     conn.query('ALTER TABLE usuario ADD ciudadd varchar(20)', (err, resp, campos) => {
//         if(!err){
//             res.json({status: 'Campo agregado a la tabla usuario sin problemas...'});
//         }else{
//             console.log(err);
            
//         }
//     });
// });

// router.get('/usuario/mytickets/:id', (req,res) => {
//     const { id } = req.params;
//     conn.query('SELECT t.id_usuario, t.id_ticket, tv.id_venta FROM ticket as t INNER JOIN ticket_venta as tv ON t.id_ticket = tv.id_ticket WHERE t.id_usuario = ?', [id] ,(err, resp, campos) => {
//         if(!err){
//             res.json(resp);
//         }else{
//             console.log(err);
            
//         }
//     });
// });

// router.get('/usuario', (req,res) => {
//     conn.query('SELECT * FROM usuario where tipo="comprador" ',(err, resp, campos) => {
//         if(!err){
//             res.json(resp);
//         }else{
//             console.log(err);
            
//         }
//     });
// });

// router.put('/usuario/:id',(req, res) => {
//     const { id } = req.params;
//     conn.query('UPDATE usuario SET nombre="Juancin", correo="juan.martinez2@gmail.com", apellido="Martinez", num_telefono="943232322", sexo="M", password="xys123ewq", rut="10232321" where id_usuario= ? and tipo="comprador"', [id],(err,resp,campos) =>{
//         if(!err) {            
//             res.json({status: 'datos de usuario modificado sin problemas...'});
//         } else {
//             console.log(err);
//         }
//     });
// }); 



module.exports = router;