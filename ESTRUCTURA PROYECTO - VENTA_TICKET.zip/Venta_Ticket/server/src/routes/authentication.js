const express = require('express');
const router = express.Router();
const conn = require('../database');
const passport = require('passport');
const { changeUser } = require('../database');


// router.get('/signin', (req,res) => {
//     res.render('signin.ejs');
// });
router.get('/signup', (req,res) =>{
    res.render('signup.ejs');
});

router.get('/login', (req,res) =>{
    res.render('login.ejs');
});

router.post('/login',passport.authenticate('local',{
    
    failureRedirect: "/login",
}), (req,res) => {
    if(req.user.tipo == 'comprador'){
        res.redirect('/usuario/evento');
    }else if(req.user.tipo == 'admin'){
        res.redirect('/administracion');
    }else{
        res.redirect('/login');
    }
});

router.get("/logout", function(req, res) {
    req.logout();
    
    res.redirect("/login");
});

router.post('/signup',(req, res) => {
    //console.log(req.body);
    const comprador = 'comprador';
    const {rut, correo, nombre, apellido, num_telefono, sexo, password} = req.body;
    conn.query('INSERT into usuario SET? ',{
        rut: rut,
        correo: correo,
        nombre: nombre,
        apellido: apellido,
        num_telefono: num_telefono,
        sexo: sexo,
        password: password
    }, (err, result) => {
        if(!err) {
            res.redirect('/login');
        } else {
            console.log(err);
        }
    });
});

//Entrar a administracion

router.get('/administracion', (req,res,next) => {
    if(req.isAuthenticated()){
        if(req.user.tipo == 'comprador' ){
            res.redirect('/usuario/evento');
        }
        return next();
    
    }
        res.redirect('/login');
},(req,res) =>{
    conn.query('Select * FROM evento', (err,resp,campos) => {
        res.render('evento.ejs',{
            datos: resp
        });
    });
});

module.exports = router;