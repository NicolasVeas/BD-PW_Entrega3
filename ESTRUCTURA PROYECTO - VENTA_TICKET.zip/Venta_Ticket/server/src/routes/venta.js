const express = require('express');
const router = express.Router();

const conn = require('../database');


//ver informacion de ventas
router.get('/ventas', (req,res,next) => {
    if(req.isAuthenticated()) return next();

        res.redirect('/login');
},(req,res) =>{
    conn.query('SELECT vt.*, p.id_usuario, p.id_ticket, p.precio, id_evento FROM venta as vt INNER JOIN (SELECT t.id_usuario, t.id_ticket, t.precio, t.id_evento, tv.id_venta FROM ticket as t INNER JOIN ticket_venta tv ON t.id_ticket = tv.id_ticket) p ON vt.id_venta = p.id_venta', (err,resp,campos) => {
        
        res.render('ventas.ejs',{
            datos: resp
        });
    });
});

// router.get('/venta', (req,res) => {
//     conn.query('SELECT * FROM venta', (err, resp, campos) => {
//         if(!err){
//             res.json(resp);
//         }else{
//             console.log(err);
            
//         }
//     });
// });

// router.put('/venta/:id',(req, res) => {
//     const { id } = req.params;
//     conn.query('UPDATE venta SET direccion="Avenida Jose Perez", hora="17:00:00" where id_venta = ?', [id],(err,resp,campos) =>{
//         if(!err) {            
//             res.json({status: 'datos de la venta modificado sin problemas...'});
//         } else {
//             console.log(err);
//         }
//     });
// }); 

// router.post('/venta',(req, res) => {
//     const { id } = req.params;
//     conn.query('INSERT INTO venta (monto_total,hora,direccion,fecha) values (3000,"17:00:00","Avenida San Nicolas","2020-08-20")', (err,resp,campos) =>{
//         if(!err) {            
//             res.json({status: 'Venta insertada sin problemas...'});
//         } else {
//             console.log(err);
//         }
//     });
// }); 

// router.delete('/venta/:id',(req, res) => {
//     const { id } = req.params;
//     conn.query('DELETE FROM venta WHERE id_venta = ?', [id],(err,resp,campos) =>{
//         if(!err) {            
//             res.json({status: 'Venta borrada sin problemas...'});
//         } else {
//             console.log(err);
//         }
//     });
// }); 

// router.put('/venta/edit/table', (req,res) => {
//     conn.query('ALTER TABLE venta ADD annnoo int(4);', (err, resp, campos) => {
//         if(!err){
//             res.json({status: 'Campo agregado a la tabla venta sin problemas...'});
//         }else{
//             console.log(err);
            
//         }
//     });
// });



module.exports = router;
